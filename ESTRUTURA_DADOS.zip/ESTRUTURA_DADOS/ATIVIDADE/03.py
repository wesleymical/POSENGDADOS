# Dicionário de diretórios por tipo de arquivo
dict_diretorio = {
    '.csv': 'D:/mical/Documents/POS ENGENHARIA DE DADOS/MATERIAS/ED/ATIVIDADE',
    '.zip': 'D:/mical/Documents/POS ENGENHARIA DE DADOS/MATERIAS/ED/ARQUIVOS',
    '.pdf': 'D:/mical/Documents/POS ENGENHARIA DE DADOS/MATERIAS/ED/ATIVIDADE'
}